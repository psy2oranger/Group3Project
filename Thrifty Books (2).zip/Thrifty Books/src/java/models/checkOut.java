/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.*;
import util.DatabaseConnector;

/**
 *
 * @author jayrenee97
 */
public class checkOut {
    
    private String title;
    private int price;
    private int itemCount;
    private boolean creditStatus;
    private String billingAddress;
    private String paymentType;
    private Timestamp orderDate;
    private String orderId;
    
    private Connection connection;
    
    public checkOut(){
    connection = DatabaseConnectorgetConnection();
    }

    public checkOut(String title, double price, int itemCount, boolean creditStatus, String billingAddress, String paymentType, Timestamp orderDate, int orderId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public boolean isCreditStatus() {
        return creditStatus;
    }

    public void setCreditStatus(boolean creditStatus) {
        this.creditStatus = creditStatus;
    }

    public String getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(String billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    
    public void checkOutForm(String title, double price, int itemCount, 
            boolean creditStatus, String billingAddress, String paymentType,
            Timestamp orderDate, int orderId){
    
    try{
       connection = DatabaseConnector.getConnection();
        
        //query database
        String sql = "insert into orders values('"+ title + "' , " + price + "," + itemCount + ", " + creditStatus + ", '" + billingAddress + "' , '" + paymentType +"'," + orderDate +" , " + orderId + " )";
        
        //create sql statement obj to send to db
        
        Statement stmt = connection.createStatement();
        
        //execute query(update)
        stmt.executeUpdate(sql);
        
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
        
    }

    
        
    }
    

