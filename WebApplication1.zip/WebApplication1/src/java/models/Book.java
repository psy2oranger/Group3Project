/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.*;
import util.DatabaseConnector;

/**
 *
 * @author jayrenee97
 */
public class Book {

    public static void addBook(String title, String author, int bn, double price) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private String genre;
    private String author;
    private String publisher;
    private int isbn;
    private String title;
    private double price;
    
    
    private Connection connection;
    private String availability;
    
    public Book(){
        connection = DatabaseConnector.getConnection();    
    }
    
    public Book(String availability, String genre, double price, String author, String publisher, int isbn, String title){
        this.author = author;
        this.price = price;
        this.genre = genre;
        this.isbn = isbn;
        this.title = title;
        this.publisher = publisher;
        this.availability = availability;
    }

    public Book(String title, String author, int bn, double price) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public double getTitle(){
        return price;
    }
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
    
   public void addBook(String title, String publisher, String author, String genre, int isbn){
       try{
       connection = DatabaseConnector.getConnection();
       
       //write query
       String sql = "insert into Books values('" + title + 
                    "'," + author +"," + isbn + ")";
            
       //create statement obj to send to db
       Statement stmt = connection.createStatement();
       
       //execute query 
       stmt.executeUpdate(sql);
       }catch(SQLException ex){
           System.out.println(ex.getMessage());
       }finally{
           DatabaseConnector.closeConnection();
       }
   }
    
}
