/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.*;
import java.sql.SQLException;
import util.DatabaseConnector;

/**
 *
 * @author jayrenee97
 */
public class books {
    private String title;
    private String author;
    private String publisher;
    private String genre;
    private double price;
    private String availabilty;
    private int isbn;
    
    private Connection connection;
    
    //constructor(creates connection)
    public books(){
    connection = DatabaseConnector.getConnection();
    }
    
    //another constructor w/parameters
    public books(String title, String author, String publisher, String genre, double price, String availability, int isbn ){
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.genre = genre;
        this.price = price;
        this.availabilty = availability;
        this.isbn = isbn;
    
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAvailabilty() {
        return availabilty;
    }

    public void setAvailabilty(String availabilty) {
        this.availabilty = availabilty;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }
    
   
    
    //method to add a book to database
    public void addBook(String title, String author, String publisher, String genre, double price, String availability, int isbn){
    //incase of sql exception
    try{
        connection = DatabaseConnector.getConnection();
        
        //query database
        String sql = "insert into books values('"+ title + "' , '" + author + "','" + publisher + "', '" + genre + "', " + price + " , '" + availability +"'," + isbn +" )";
        
        //create sql statement obj to send to db
        
        Statement stmt = connection.createStatement();
        
        //execute query(update)
        stmt.executeUpdate(sql);
        
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
        
    }
}


    

