/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import util.DatabaseConnector;

/**
 *
 * @author jayrenee97
 */
public class customers {
    private int id;
    private String firstName;
    private String lastName;
    private String Address;
    private int phone;
    private String email;
    private boolean creditStatus;
    
     private Connection connection;
    
    public customers(){
        connection = DatabaseConnector.getConnection();
    }

    public customers(int id, String firstName, String lastName, String Address, int phone, String email, boolean creditStatus) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.Address = Address;
        this.phone = phone;
        this.email = email;
        this.creditStatus = creditStatus;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean getCreditStatus() {
        return creditStatus;
    }

    public void setCreditStatus(boolean creditStatus) {
        this.creditStatus = creditStatus;
    }
    
    public void shoppingCart(int id, String firstName, String lastName, String address, int phone, String email, boolean creditStatus ){
  
      try{
        connection = DatabaseConnector.getConnection();
        
        //query database
        String sql = "Select from customers values(" + id + ",'" + firstName + "' , '" + lastName + "','" + address + "', " + phone + ",'" + email + "','" + creditStatus + "' )";
        
        //create sql statement obj to send to db
        
        Statement stmt = connection.createStatement();
        
        //execute query(update)
        stmt.executeUpdate(sql);
        
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
    
    
    }

    public void customerRecord(int id, String firstName, String lastName, String address, int phone, String email, boolean creditStatus) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
