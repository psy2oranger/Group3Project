/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import util.DatabaseConnector;

/**
 *
 * @author jayrenee97
 */
public class viewBooks {


    private String title;
    private String author;
    private String publisher;
    private String genre;
    private double price;
    private String availabilty;
    private int isbn;
    
    private Connection connection;

    
    //constructor(creates connection)
    public viewBooks(){
    connection = DatabaseConnector.getConnection();
    }
    
    //another constructor w/parameters
    public viewBooks(String title, String author, String publisher, String genre, double price, String availabilty, int isbn ){
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.genre = genre;
        this.price = price;
        this.availabilty = availabilty;
        this.isbn = isbn;
    
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAvailabilty() {
        return availabilty;
    }

    public void setAvailabilty(String availabilty) {
        this.availabilty = availabilty;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }
    
   
    
   
        
    

    
    
     public ArrayList<viewBooks> viewAllBooks(){
      ArrayList<viewBooks> viewAllBooks = new ArrayList<>();
      connection = DatabaseConnector.getConnection();
      
      try{
        
         String sql = "Select * from books";
        Statement stmt = connection.createStatement();
        
        //execute query(update)
        ResultSet result = stmt.executeQuery(sql);
       
        while(result.next()){
            String title;
            String author;
            String publisher;
            String genre;
            double price;
            String availabilty;
            int isbn;
            
            title = result.getString("title");
            author = result.getString("author");
            publisher = result.getString("publisher");
            genre = result.getString("genre");
            price = result.getDouble("price");
            availabilty = result.getString("availabilty");
            isbn = result.getInt("isbn");
            
            viewBooks  book = new viewBooks(title, author, publisher, genre, price, availabilty, isbn);
            viewAllBooks.add(book);
            
        }
       
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
       
  
  return viewAllBooks;

  }
}
