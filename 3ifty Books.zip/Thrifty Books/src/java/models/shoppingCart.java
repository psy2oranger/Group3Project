/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import util.DatabaseConnector;

/**
 *
 * @author jayrenee97
 */
public class shoppingCart {

   

  
    private String title;
    private int isbn;
    private double price;
   
    
   private static Connection connection;
    
   public  shoppingCart(){
       connection = DatabaseConnector.getConnection();
    
   }
    public shoppingCart(String title, int isbn, double price) {
       
        this.title = title;
        this.isbn = isbn;
        this.price = price;
      
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getIsbn() {
        return isbn;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    
     public void addShoppingCart(String title, double price, int isbn){
    //incase of sql exception
    try{
        connection = DatabaseConnector.getConnection();
        
        //query database
        String sql = "insert into shoppingCart ('"+ title + "' , " + isbn + ", " + price + ")";
        
        //create sql statement obj to send to db
        
        Statement stmt = connection.createStatement();
        
        //execute query(update)
        stmt.executeUpdate(sql);
        
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
        
    }
     
   
     
    
    
  public ArrayList<shoppingCart> viewShoppingCart(){
      ArrayList<shoppingCart> viewShoppingCart = new ArrayList<>();
      connection = DatabaseConnector.getConnection();
      
      try{
        
        String sql = "Select title, isbn, price from books";
        Statement stmt = connection.createStatement();
        
        //execute query(update)
        ResultSet result = stmt.executeQuery(sql);
       
        while(result.next()){
            String title;
            int isbn;
            double price;
            
            title = result.getString("title");
            isbn = result.getInt("isbn");
            price = result.getDouble("price");
            
            shoppingCart shop = new shoppingCart(title, isbn, price);
            viewShoppingCart.add(shop);
            
        }
       
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
       
  
  return viewShoppingCart;

  }

}
