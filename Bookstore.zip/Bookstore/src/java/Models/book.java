/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Connection;
import java.sql.*;
import java.sql.SQLException;
import Util.DatabaseConnector;
import java.util.ArrayList;


/**
 *
 * @author ADmin
 */
public class book {
    private String title;
    private String author;
    private String publisher;
    private String genre;
    private double price;
    private String availability;
    private String isbn;
    
    private Connection connection;
   
    
    //constructor(creates connection)
    public book(){
    connection = DatabaseConnector.getConnection();
    }
    
    //another constructor w/parameters
    public book(String title, String author, String publisher, String genre, double price, String availability, String isbn ){
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.genre = genre;
        this.price = price;
        this.availability = availability;
        this.isbn = isbn;
    
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAvailabilty() {
        return availability;
    }

    public void setAvailabilty(String availabilty) {
        this.availability = availability;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    
   
    
    public ArrayList<book> searchBooks(){
        //array list to store current books in stock
        ArrayList<book> booklist = new ArrayList<>();
        //connect to database
        connection = DatabaseConnector.getConnection();
        try{
            //execute a basic query to get the books
            String sql = "select * from book";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            //for each record, create a new object and put it in the arraylist
            while(rs.next()){
                String title;
                String isbn;
                String author;
                String genre;
                String availabilty;
                double price;
                String publisher;
                
                title = rs.getString("title");
                isbn = rs.getString("isbn");
                author = rs.getString("author");
                genre = rs.getString("genre");
                price = rs.getDouble("price");
                availabilty = rs.getString("availabilty");
                publisher = rs.getString("publisher");
                
                book boo = new book (title, author, publisher, genre, price, availabilty, isbn);
                booklist.add(boo);
                
            }
            
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }finally{
            DatabaseConnector.closeConnection();
        }
        
        return booklist;
    
}   
    public ArrayList <book> viewBooks(String genre){
    //incase of sql exception
    
     ArrayList<book> booklist = new ArrayList<>();
    
    try{
        connection = DatabaseConnector.getConnection();
       
        //query database
        String sql = "Select * from books where genre like ?";
        
        //create sql statement obj to send to db
        
        PreparedStatement stmt = connection.prepareStatement(sql);
        
        //execute query(update)
       // stmt.setInt(1, isbn);
       // stmt.setString(2, title);
       // stmt.setString(3, author);
        stmt.setString(1, genre);
        
        ResultSet rs = stmt.executeQuery();
        
        while(rs.next()){
              
                
               // title = rs.getString("title");
               // isbn = rs.getInt("isbn");
               // author = rs.getString("author");
               // genre = rs.getString("genre");
                
                book boo = new book (rs.getString("title"),rs.getString("author"),rs.getString(3),rs.getString("genre"),rs.getDouble("price"),rs.getString("availabilty"),rs.getString("isbn"));
                booklist.add(boo);
        }
        
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        
    }finally{
        DatabaseConnector.closeConnection();
    }
       return booklist;
    }
    
}
        
    
